import React from 'react'
import ReactDOM from 'react-dom/client'
import { WagmiProvider } from 'wagmi'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { wagmiConfig } from './config.js'
import App from './App.jsx'
import './style.css'
const queryClient = new QueryClient()
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><WagmiProvider config={wagmiConfig}><QueryClientProvider client={queryClient}><App /></QueryClientProvider></WagmiProvider></React.StrictMode>)
