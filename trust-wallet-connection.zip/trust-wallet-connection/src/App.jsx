import { useAccount, useChainId } from 'wagmi'
export default function App(){
 const {address,isConnected}=useAccount(); const chainId=useChainId()
 return <main><section className="card"><small>BNB SMART CHAIN</small><h1>اتصال تراست‌ولت</h1><p>این صفحه فقط کیف پول را وصل می‌کند و آدرس عمومی آن را نشان می‌دهد.</p><div className="button"><appkit-button /></div><p>وضعیت اتصال: {isConnected?'وصل است':'وصل نیست'}</p>{isConnected&&<div className="info"><b>آدرس عمومی کیف پول</b><code>{address}</code><b>شناسه شبکه</b><code>{chainId}</code></div>}<aside><b>نکته امنیتی</b><p>این نسخه هیچ انتقال پول، امضا یا تأیید قرارداد انجام نمی‌دهد. عبارت بازیابی و کلید خصوصی را هرگز وارد نکن. اگر درخواست امضا یا انتقال دیدی، رد کن.</p></aside></section><footer>نسخه آزمایشی — بدون تراکنش مالی</footer></main>
}
