import { createAppKit } from '@reown/appkit/react'
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'
import { bsc } from '@reown/appkit/networks'
export const projectId = 'b61b178f47f8ddc2b92962f4385d862e'
export const networks = [bsc]
const adapter = new WagmiAdapter({ projectId, networks })
export const wagmiConfig = adapter.wagmiConfig
createAppKit({
  adapters:[adapter], projectId, networks, defaultNetwork:bsc,
  metadata:{name:'اتصال تراست‌ولت',description:'فقط اتصال و نمایش آدرس کیف پول',url:'https://keyannikan123-ctrl.github.io',icons:[]},
  features:{analytics:false,email:false,socials:false,onramp:false,swaps:false,send:false,receive:false},
  themeMode:'dark'
})
